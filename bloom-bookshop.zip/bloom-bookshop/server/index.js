const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

// Dummy Data
const categories = ["Fiction", "Non-Fiction", "Kids' Book", "Romance", "Fantasy", "Discovery", "Business", "Sports"];

const books = Array.from({ length: 1000 }, (_, i) => ({
  id: i + 1,
  title: `Book Title ${i + 1}`,
  author: `Author ${i + 1}`,
  category: categories[Math.floor(Math.random() * categories.length)],
  price: (Math.random() * (39.99 - 5.99) + 5.99).toFixed(2),
}));

// API Endpoints
app.get('/api/books', (req, res) => {
  res.json(books);
});

app.get('/api/books/:id', (req, res) => {
  const book = books.find(b => b.id === parseInt(req.params.id));
  if (book) {
    res.json(book);
  } else {
    res.status(404).json({ message: 'Book not found' });
  }
});

app.listen(5001, () => console.log('Server running on port 5001'));
