import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import axios from "axios";
import "./Home.css";
import heroImage from "../assets/hero.jpg"; // Correct import path

const Home = () => {
  const [books, setBooks] = useState([]);
  const navigate = useNavigate(); // Hook for navigation

  useEffect(() => {
    axios
      .get("https://openlibrary.org/subjects/fantasy.json?limit=12") // Fetch 12 books
      .then((response) => {
        if (response.data.works) {
          setBooks(response.data.works);
        }
      })
      .catch((error) => console.error("Error fetching books:", error));
  }, []);

  return (
    <div className="page-container">
      {/* Pass a prop to hide the catalog button */}
      <Navbar hideCatalog={true} />

      <header className="hero" style={{ backgroundImage: `url(${heroImage})` }}>
        <input type="text" className="search-bar" placeholder=" 🔍 Search Book" />
        <div className="category-buttons">
          {["Fiction", "Non-Fiction", "Kids' Book", "Romance", "Fantasy", "Discovery", "Business", "Sports"].map(
            (category) => (
              <button key={category} className="category-btn">
                {category}
              </button>
            )
          )}
        </div>
        <h1>Bloom Bookshop</h1>
        <p>Step Into Your Local Bookstore, Online: Expertly Curated, Community-Driven</p>
        <button className="shop-now" onClick={() => navigate("/catalog")}>
          SHOP NOW
        </button>
      </header>

      <section className="who-we-are">
        <h2>Who We Are</h2>
        <p>
          Welcome to Bloom, your favorite hometown bookstore now online! We're passionate about sharing the joy of
          reading and connecting book lovers everywhere.
        </p>
        <p>
          At Bloom, we’re more than booksellers – we’re community builders. Discover curated selections, lively events,
          and your next favorite book with us.
        </p>
        <p>
          Trust Bloom for expertly curated books, author talks, and workshops, all guided by passionate booksellers with
          decades of expertise.
        </p>
        <blockquote>
          <i>"There is no friend as loyal as a book."</i>
          <br />– Ernest Hemingway
        </blockquote>
      </section>

      <section className="recommendations">
        <h2>What Booksellers Recommend</h2>

        <h3>Faridah’s Picks</h3>
        <div className="book-list">
          {books.slice(0, 6).map((book) => (
            <div key={book.key} className="book-item">
              <img
                src={
                  book.cover_id
                    ? `https://covers.openlibrary.org/b/id/${book.cover_id}-M.jpg`
                    : "https://via.placeholder.com/150"
                }
                alt={book.title}
                className="book-cover"
              />
              <h4>{book.title}</h4>
              <p>By {book.authors?.[0]?.name || "Unknown Author"}</p>
            </div>
          ))}
        </div>

        <h3>John’s Picks</h3>
        <div className="book-list">
          {books.slice(6, 12).map((book) => (
            <div key={book.key} className="book-item">
              <img
                src={
                  book.cover_id
                    ? `https://covers.openlibrary.org/b/id/${book.cover_id}-M.jpg`
                    : "https://via.placeholder.com/150"
                }
                alt={book.title}
                className="book-cover"
              />
              <h4>{book.title}</h4>
              <p>By {book.authors?.[0]?.name || "Unknown Author"}</p>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Home;
