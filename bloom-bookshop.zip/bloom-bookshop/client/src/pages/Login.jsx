import React from 'react';
import './Login.css';

const Login = () => {
  return (
    <div className="login-container">
      <h1>Welcome to Bloom Bookshop!</h1>
      <input type="text" placeholder="Enter your email" />
      <input type="password" placeholder="Enter your password" />
      <button>Login</button>
    </div>
  );
};

export default Login;