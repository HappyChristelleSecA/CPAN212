import React from 'react';
import './Product.css';

const Product = () => {
  return (
    <div className="product-container">
      <h1>Product Details</h1>
      <p>Specific book details here</p>
    </div>
  );
};

export default Product;