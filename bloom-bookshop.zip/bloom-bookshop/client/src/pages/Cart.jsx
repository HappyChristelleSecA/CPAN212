import React from 'react';
import './Cart.css';

const Cart = () => {
  return (
    <div className="cart-container">
      <h1>Your Cart Details</h1>
      <p>Items will be displayed here</p>
    </div>
  );
};

export default Cart;