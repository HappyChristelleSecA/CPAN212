import React from 'react';
import './Register.css';

const Register = () => {
  return (
    <div className="register-container">
      <h1>Register</h1>
      <input type="text" placeholder="Enter your name" />
      <input type="email" placeholder="Enter your email" />
      <input type="password" placeholder="Enter your password" />
      <button>Register</button>
    </div>
  );
};

export default Register;