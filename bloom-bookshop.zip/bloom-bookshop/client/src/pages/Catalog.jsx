import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import './Catalog.css';

const Catalog = () => {
  const [books, setBooks] = useState([]);
  const placeholderImage = 'https://via.placeholder.com/150?text=Book+Cover';

  useEffect(() => {
    axios.get('http://localhost:5001/api/books')
      .then(response => {
        console.log("Books data:", response.data); // Debugging API response
        setBooks(response.data);
      })
      .catch(error => console.error('Error fetching books:', error));
  }, []);

  return (
    <div className="catalog-page">
      <Navbar />
      <div className="catalog-container">
        <h1>Books</h1>
        <input type="text" className="search-box" placeholder="🔍 Search Book" />
        <div className="book-grid">
          {books.length > 0 ? (
            books.map((book, index) => (
              <div key={book.id || index} className="book-item">
                <img
                  src={book.image ? book.image : placeholderImage}
                  alt={book.title || "No Title"}
                  className="book-cover"
                />
                <h3>{book.title}</h3>
                <p>{book.author}</p>
                <strong>${book.price}</strong>
              </div>
            ))
          ) : (
            <p>Loading books...</p>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Catalog;