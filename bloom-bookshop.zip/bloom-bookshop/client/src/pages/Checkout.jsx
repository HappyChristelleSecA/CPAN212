import React from 'react';
import './Checkout.css';

const Checkout = () => {
  return (
    <div className="checkout-container">
      <h1>Checkout</h1>
      <p>Shipping and payment details</p>
    </div>
  );
};

export default Checkout;