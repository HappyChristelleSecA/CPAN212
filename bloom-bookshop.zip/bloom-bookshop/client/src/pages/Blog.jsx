import React from 'react';

const Blog = () => {
  return (
    <div>
      <h1>Blog Page</h1>
      <p>Welcome to the blog! More content coming soon.</p>
    </div>
  );
};

export default Blog;
