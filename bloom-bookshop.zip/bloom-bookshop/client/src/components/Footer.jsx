import React from "react";
import "./Footer.css";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        {/* Left Section */}
        <div className="footer-links">
          <ul>
            <li><strong>FAQ</strong></li>
            <li><strong>Shipping & Returns Policy</strong></li>
            <li><strong>About Us</strong></li>
            <li><strong>Terms and Conditions</strong></li>
          </ul>
          {/* Social Icons */}
          <div className="social-icons">
            <a href="#"><i className="fab fa-instagram"></i></a>
            <a href="#"><i className="fab fa-facebook"></i></a>
            <a href="#"><i className="fab fa-twitter"></i></a>
          </div>
        </div>

        {/* Right Section */}
        <div className="footer-subscribe">
          <h3>Stay Updated</h3>
          <div className="subscribe-form">
            <input type="email" placeholder="Your email..." />
            <button>SUBSCRIBE</button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
